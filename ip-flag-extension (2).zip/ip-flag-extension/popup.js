const loadingEl = document.getElementById("loading");
const contentEl = document.getElementById("content");
const errorBoxEl = document.getElementById("errorBox");
const refreshBtn = document.getElementById("refreshBtn");

function formatTime(isoString) {
  if (!isoString) return "";
  const d = new Date(isoString);
  return "آخرین به‌روزرسانی: " + d.toLocaleTimeString("fa-IR");
}

function render(info) {
  loadingEl.classList.add("hidden");

  if (!info || info.error) {
    contentEl.classList.add("hidden");
    errorBoxEl.classList.remove("hidden");
    errorBoxEl.textContent = (info && info.error) || "اطلاعاتی موجود نیست. روی «به‌روزرسانی» بزنید.";
    return;
  }

  errorBoxEl.classList.add("hidden");
  contentEl.classList.remove("hidden");

  document.getElementById("ip").textContent = info.ip || "-";
  document.getElementById("country").textContent = info.country || "-";
  document.getElementById("city").textContent = info.city || "-";
  document.getElementById("region").textContent = info.region || "-";
  document.getElementById("updatedAt").textContent = formatTime(info.updatedAt);

  const leakBoxEl = document.getElementById("leakBox");
  if (info.hasLeak) {
    leakBoxEl.classList.remove("ok");
    leakBoxEl.classList.add("bad");
    leakBoxEl.innerHTML =
      "⚠ نشتی IP شناسایی شد!" +
      (info.leakedIps && info.leakedIps.length
        ? `<span class="leaked-ips">${info.leakedIps.join(", ")}</span>`
        : "");
  } else {
    leakBoxEl.classList.remove("bad");
    leakBoxEl.classList.add("ok");
    leakBoxEl.textContent = "✓ نشتی‌ای شناسایی نشد";
  }

  const flagImg = document.getElementById("flagImg");
  if (info.countryCode) {
    flagImg.src = `https://flagcdn.com/w160/${info.countryCode.toLowerCase()}.png`;
    flagImg.alt = "پرچم " + info.country;
  } else {
    flagImg.removeAttribute("src");
  }
}

function loadFromStorage() {
  chrome.storage.local.get("ipInfo", (res) => {
    render(res.ipInfo);
  });
}

refreshBtn.addEventListener("click", () => {
  loadingEl.classList.remove("hidden");
  contentEl.classList.add("hidden");
  errorBoxEl.classList.add("hidden");

  chrome.runtime.sendMessage({ type: "REFRESH_IP_FLAG" }, () => {
    loadFromStorage();
  });
});

loadFromStorage();
