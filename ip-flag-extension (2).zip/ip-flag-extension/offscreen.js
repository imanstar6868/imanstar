// offscreen.js
// این اسکریپت داخل یک "offscreen document" اجرا می‌شود، چون service worker
// در Manifest V3 به RTCPeerConnection دسترسی قابل‌اعتماد ندارد.
// وظیفه: با WebRTC/STUN، آی‌پی‌(های) واقعی که ممکن است از زیر فیلترشکن
// «نشت» کرده باشند را پیدا کند.

const STUN_SERVERS = [
  { urls: "stun:stun.l.google.com:19302" },
  { urls: "stun:stun1.l.google.com:19302" }
];

function detectWebRtcIps(timeoutMs) {
  return new Promise((resolve) => {
    const ips = new Set();
    let settled = false;
    let pc;

    const finish = () => {
      if (settled) return;
      settled = true;
      try { pc && pc.close(); } catch (e) {}
      resolve(Array.from(ips));
    };

    try {
      pc = new RTCPeerConnection({ iceServers: STUN_SERVERS });
    } catch (e) {
      resolve([]);
      return;
    }

    // یک data channel خالی فقط برای این‌که مذاکره ICE شروع شود لازم است
    try {
      pc.createDataChannel("leak-check");
    } catch (e) {
      // نادیده گرفته می‌شود
    }

    pc.onicecandidate = (event) => {
      if (!event) return;
      if (!event.candidate) {
        // null candidate یعنی جمع‌آوری candidate ها تمام شده
        finish();
        return;
      }
      const candidateStr = event.candidate.candidate || "";
      const matches = candidateStr.match(/\b\d{1,3}(?:\.\d{1,3}){3}\b/g);
      if (matches) {
        matches.forEach((ip) => ips.add(ip));
      }
    };

    pc.createOffer()
      .then((offer) => pc.setLocalDescription(offer))
      .catch(() => finish());

    setTimeout(finish, timeoutMs);
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "CHECK_WEBRTC_LEAK") {
    detectWebRtcIps(3000).then((ips) => sendResponse({ ips }));
    return true; // پاسخ async
  }
});
