// background.js
// وظیفه: گرفتن آی‌پی و کشور فعلی کاربر، و رسم پرچم واقعی آن کشور روی آیکون افزونه

const ALARM_NAME = "refresh-ip-flag";
const REFRESH_MINUTES = 5; // هر چند دقیقه یک‌بار به‌صورت خودکار بررسی شود

// چند سرویس مختلف امتحان می‌شوند؛ اگر یکی به هر دلیلی (بلاک‌شدن توسط
// ادبلاکر، محدودیت نرخ، قطعی سرویس و ...) شکست بخورد، سراغ بعدی می‌رود.
const PROVIDERS = [
  {
    // GeoJS مخصوص استفاده از سمت کلاینت (از جمله اکستنشن‌های مرورگر) طراحی شده
    // و برخلاف ipapi.co، درخواست‌هایی با Origin از نوع chrome-extension:// را بلاک نمی‌کند.
    name: "geojs.io",
    url: "https://get.geojs.io/v1/ip/geo.json",
    parse: (data) => ({
      ip: data.ip,
      country: data.country,
      countryCode: data.country_code,
      city: data.city,
      region: data.region
    })
  },
  {
    name: "ipwho.is",
    url: "https://ipwho.is/",
    parse: (data) => {
      if (data.success === false) throw new Error(data.message || "ipwho.is خطا داد");
      return {
        ip: data.ip,
        country: data.country,
        countryCode: data.country_code,
        city: data.city,
        region: data.region
      };
    }
  },
  {
    name: "freeipapi.com",
    url: "https://freeipapi.com/api/json/",
    parse: (data) => ({
      ip: data.ipAddress,
      country: data.countryName,
      countryCode: data.countryCode,
      city: data.cityName,
      region: data.regionName
    })
  }
];

const OFFSCREEN_URL = "offscreen.html";

async function ensureOffscreenDocument() {
  const existing = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_URL)]
  });
  if (existing && existing.length > 0) return;

  await chrome.offscreen.createDocument({
    url: OFFSCREEN_URL,
    reasons: ["WEB_RTC"],
    justification:
      "بررسی نشتی IP واقعی از طریق WebRTC برای مقایسه با IP گزارش‌شده‌ی فیلترشکن"
  });
}

function isPrivateOrLocalIp(ip) {
  return (
    /^10\./.test(ip) ||
    /^192\.168\./.test(ip) ||
    /^172\.(1[6-9]|2\d|3[01])\./.test(ip) ||
    /^127\./.test(ip) ||
    /^169\.254\./.test(ip) ||
    ip === "0.0.0.0"
  );
}

// آی‌پی‌هایی که WebRTC از طریق STUN پیدا می‌کند را با آی‌پی گزارش‌شده توسط
// سرویس‌های فیلترشکن مقایسه می‌کند. اگر آی‌پی عمومی دیگری (متفاوت از آی‌پی
// فعلی فیلترشکن) پیدا شود، یعنی آی‌پی واقعی کاربر «نشت» کرده است.
async function checkWebRtcLeak(currentIp) {
  try {
    await ensureOffscreenDocument();
    const response = await chrome.runtime.sendMessage({ type: "CHECK_WEBRTC_LEAK" });
    const ips = (response && response.ips) || [];
    const publicIps = ips.filter((ip) => !isPrivateOrLocalIp(ip));
    const leakedIps = publicIps.filter((ip) => ip !== currentIp);
    return { hasLeak: leakedIps.length > 0, leakedIps, allWebrtcIps: ips };
  } catch (e) {
    console.warn("بررسی نشتی WebRTC ناموفق بود:", e);
    return { hasLeak: false, leakedIps: [], allWebrtcIps: [], checkError: e.message };
  }
}

async function fetchIpInfo() {
  const errors = [];
  for (const provider of PROVIDERS) {
    try {
      const res = await fetch(provider.url, { cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const parsed = provider.parse(data);
      if (!parsed.countryCode) throw new Error("کد کشور در پاسخ یافت نشد");
      return parsed;
    } catch (e) {
      console.warn(`سرویس ${provider.name} شکست خورد:`, e);
      errors.push(`${provider.name}: ${e.message}`);
    }
  }
  throw new Error(errors.join(" | "));
}

async function updateFlag() {
  try {
    const parsed = await fetchIpInfo();
    const countryCode = (parsed.countryCode || "").toLowerCase();

    const leak = await checkWebRtcLeak(parsed.ip);

    const info = {
      ip: parsed.ip || "نامشخص",
      country: parsed.country || "نامشخص",
      countryCode: (parsed.countryCode || "").toUpperCase(),
      city: parsed.city || "",
      region: parsed.region || "",
      updatedAt: new Date().toISOString(),
      hasLeak: leak.hasLeak,
      leakedIps: leak.leakedIps,
      error: null
    };

    await chrome.storage.local.set({ ipInfo: info });

    if (countryCode) {
      await setIconFromFlag(countryCode);
    }

    const leakLine = info.hasLeak
      ? `\n⚠ نشتی IP شناسایی شد: ${info.leakedIps.join(", ")}`
      : "";
    await chrome.action.setTitle({
      title: `IP: ${info.ip}\nکشور: ${info.country}${info.city ? "\nشهر: " + info.city : ""}${leakLine}`
    });

    if (info.hasLeak) {
      await chrome.action.setBadgeText({ text: "!" });
      await chrome.action.setBadgeBackgroundColor({ color: "#dc2626" });
    } else {
      await chrome.action.setBadgeText({ text: "" });
    }
  } catch (e) {
    console.error("خطا در به‌روزرسانی پرچم IP:", e);
    await chrome.storage.local.set({
      ipInfo: {
        error:
          "دریافت اطلاعات IP از همه‌ی سرویس‌ها ناموفق بود. جزئیات: " +
          e.message +
          " — احتمالاً یک افزونه‌ی ادبلاکر/حریم‌خصوصی این دامنه‌ها را مسدود کرده، یا اتصال اینترنت قطع است.",
        updatedAt: new Date().toISOString()
      }
    });
    await chrome.action.setBadgeText({ text: "!" });
    await chrome.action.setBadgeBackgroundColor({ color: "#dc2626" });
    await chrome.action.setTitle({ title: "خطا در دریافت اطلاعات IP - کلیک کنید برای تلاش دوباره" });
  }
}

async function setIconFromFlag(countryCode) {
  const sizes = [16, 32, 48, 128];
  // تصویر پرچم با کیفیت بالا از flagcdn گرفته می‌شود
  const flagUrl = `https://flagcdn.com/w160/${countryCode}.png`;

  const res = await fetch(flagUrl, { cache: "no-store" });
  if (!res.ok) throw new Error("پرچم یافت نشد");
  const blob = await res.blob();
  const bitmap = await createImageBitmap(blob);

  const imageData = {};
  for (const size of sizes) {
    const canvas = new OffscreenCanvas(size, size);
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, size, size);

    // پرچم را با حفظ نسبت ابعاد، وسط‌چین رسم می‌کنیم
    const scale = Math.min(size / bitmap.width, size / bitmap.height);
    const w = bitmap.width * scale;
    const h = bitmap.height * scale;
    const x = (size - w) / 2;
    const y = (size - h) / 2;

    ctx.drawImage(bitmap, x, y, w, h);
    imageData[size] = ctx.getImageData(0, 0, size, size);
  }

  await chrome.action.setIcon({ imageData });
}

chrome.runtime.onInstalled.addListener(() => {
  updateFlag();
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: REFRESH_MINUTES });
  chrome.idle.setDetectionInterval(60); // بعد از ۶۰ ثانیه بی‌کاری، "idle" در نظر گرفته می‌شود
});

chrome.runtime.onStartup.addListener(() => {
  updateFlag();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) {
    updateFlag();
  }
});

// وقتی مرورگر به شبکه وصل می‌شود (تغییر وای‌فای، قطع/وصل VPN و ...) بلافاصله بررسی مجدد انجام می‌شود
self.addEventListener("online", () => {
  console.log("رویداد آنلاین‌شدن شبکه شناسایی شد؛ در حال به‌روزرسانی IP...");
  updateFlag();
});

// وقتی سیستم از حالت خواب/قفل بیدار می‌شود (مثلاً باز کردن لپ‌تاپ در مکان جدید)،
// این خودش نشانه‌ی خوبی برای تغییر احتمالی شبکه/IP است
chrome.idle.onStateChanged.addListener((state) => {
  if (state === "active") {
    console.log("سیستم از حالت idle/locked فعال شد؛ در حال بررسی مجدد IP...");
    updateFlag();
  }
});

// امکان درخواست به‌روزرسانی دستی از پاپ‌آپ
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "REFRESH_IP_FLAG") {
    updateFlag().then(() => sendResponse({ ok: true }));
    return true; // پاسخ async
  }
});

// اگر روی آیکون کلیک شد و پاپ‌آپ باز نشد (حالت خطا)، دوباره تلاش کن
chrome.action.onClicked.addListener(() => {
  updateFlag();
});
